<div class="bg-dark text-white py-2">
    <div class="d-flex justify-content-between mx-5">
        <h3>NFT Catalogue</h3>
        <div class="d-flex justify-content-around text-primary align-items-center">
            <h5 class="mx-2">
                <a href="/user">Users</a>
            </h5>
            <h5 class="mx-2">
                <a href="/nft">NFTs</a>
            </h5>
        </div>
    </div>
</div>