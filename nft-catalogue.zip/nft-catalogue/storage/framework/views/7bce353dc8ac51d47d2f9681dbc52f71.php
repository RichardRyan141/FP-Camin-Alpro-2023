
<?php $__env->startSection('content'); ?>
    <h1>Users List</h1>

    <?php if(session()->has('error')): ?>
        <div class="alert alert-danger" style="margin-top: 20px">
            <?php echo e(session()->get('error')); ?>

        </div>
    <?php endif; ?>

    <?php if(session()->has('success')): ?>
        <div class="alert alert-success" style="margin-top: 20px">
            <?php echo e(session()->get('success')); ?>

        </div>
    <?php endif; ?>

    <table class="table">
        <thead>
            <tr>
                <th>UID</th>
                <th>Name</th>
                <th>Number of NFTs Owned</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pengguna): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($pengguna->uid); ?></td>
                <td><?php echo e($pengguna->name); ?></td>
                <td><?php echo e($pengguna->nft_count); ?></td>
                <td>                
                    <?php if($pengguna->name !== 'Admin'): ?>
                        <form action="<?php echo e(route('pengguna.destroy', $pengguna->uid)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this user?')">Delete</button>
                        </form>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
    </table>
    <a href="/user/create" class="btn btn-primary mb-2">Create User</a>
    <a href="/user/logout" class="btn btn-primary mb-2">Logout</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\wwwwwwwwwwwwwwwwwwww\nft-catalogue\resources\views/admin/index.blade.php ENDPATH**/ ?>