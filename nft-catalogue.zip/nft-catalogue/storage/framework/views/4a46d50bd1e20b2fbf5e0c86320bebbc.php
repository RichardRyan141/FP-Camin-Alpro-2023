
<?php $__env->startSection('content'); ?>
    <h1>Change Password <?php echo e($pengguna->id); ?></h1>

    <?php if(session()->has('error')): ?>
        <div class="alert alert-danger" style="margin-top: 20px">
            <?php echo e(session()->get('error')); ?>

        </div>
    <?php endif; ?>

    <form action="/user/change-password" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('put'); ?>
        <div class="form-group">
            <label>Current Password</label>
            <input type="password" class="form-control" name="current_password" placeholder="Enter Password">
            <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger">
                    <?php echo e($message); ?>

                </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-group">
            <label>New Password</label>
            <input type="password" class="form-control" name="new_password" placeholder="Enter New Password">
            <input type="password" class="form-control" name="new_password_confirmation" placeholder="Retype your New Password">
            <?php $__errorArgs = ['new_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger">
                    <?php echo e($message); ?>

                </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <button type="submit">Change Password</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\wwwwwwwwwwwwwwwwwwww\nft-catalogue\resources\views/pengguna/edit-password.blade.php ENDPATH**/ ?>