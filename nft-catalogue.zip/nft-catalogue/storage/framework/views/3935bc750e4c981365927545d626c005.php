
<?php $__env->startSection('content'); ?>
    <h1>Your Stats</h1>
    
    <?php if(session()->has('error')): ?>
        <div class="alert alert-danger" style="margin-top: 20px">
            <?php echo e(session()->get('error')); ?>

        </div>
    <?php endif; ?>

    <?php if(session()->has('success')): ?>
        <div class="alert alert-success" style="margin-top: 20px">
            <?php echo e(session()->get('success')); ?>

        </div>
    <?php endif; ?>

    <table class="table">
        <thead>
            <tr>
                <th>UID</th>
                <th>Name</th>
                <th>Number of NFTs Owned</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td><?php echo e($user->uid); ?></td>
                <td><?php echo e($user->name); ?></td>
                <td><?php echo e($user->nft_count); ?></td>
                <td>
                    <form action="<?php echo e(route('pengguna.destroy', $user->uid)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this user?')">Delete</button>
                    </form>
                </td>
            </tr>
        </tbody>
    </table>
    <a href="/user/logout" class="btn btn-primary mb-2">Logout</a>
    <a href="/user/change-password" class="btn btn-primary mb-2">Change Password</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\wwwwwwwwwwwwwwwwwwww\nft-catalogue\resources\views/pengguna/index.blade.php ENDPATH**/ ?>