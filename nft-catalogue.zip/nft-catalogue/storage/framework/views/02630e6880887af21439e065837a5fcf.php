
<?php $__env->startSection('content'); ?>
<h1>Edit NFT</h1>
<form action="<?php echo e(route('nft.update', $nft->id)); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo method_field('put'); ?>

    <img src="<?php echo e($nft->image_link); ?>" alt="<?php echo e($nft->name); ?>" style="margin-bottom: 20px;">

    <div class="form-group">
        <label>Name</label>
        <input type="text" name="name" class="form-control" value="<?php echo e($nft->name); ?>">
        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-danger">
                <?php echo e($message); ?>

            </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="form-group">
        <label>Description</label>
        <input type="text" name="description" class="form-control" value="<?php echo e($nft->description); ?>">
        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-danger">
                <?php echo e($message); ?>

            </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="form-group">
        <label>Owner: </label>
        <label style="font-weight: bold;"><?php echo e($pemilik->name); ?></label>
    </div>

    <div class="d-flex justify-content-between">
        <a href="/nft" class="btn btn-light"><< Back</a>
        <button type="submit">Update</button>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\wwwwwwwwwwwwwwwwwwww\nft-catalogue\resources\views/nft/edit.blade.php ENDPATH**/ ?>